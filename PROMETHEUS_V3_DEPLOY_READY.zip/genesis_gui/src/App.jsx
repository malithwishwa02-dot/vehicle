import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Activity, Database, Play, Wifi, CreditCard, User, Clock, Download, Brain, Sparkles, MapPin } from 'lucide-react';

// API ENDPOINT - CONFIGURATION
// FOR LOCAL DEV: Leave as "" to use Vite Proxy (localhost:3000 -> localhost:5000)
// FOR VPS DEPLOYMENT: Change to "http://<YOUR_VPS_IP>:5000"
const API_URL = "";

export default function App() {
  const [config, setConfig] = useState({
    identity: { firstName: '', lastName: '', address: '', city: '', state: '', zip: '', country: 'US' },
    financial: { ccNumber: '', expiry: '', cvv: '' },
    network: { host: '', port: '', username: '', password: '', protocol: 'http' },
    chronos: { genesisOffsetDays: 90 }
  });

  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [terminalLogs, setTerminalLogs] = useState([{ text: "PROMETHEUS-CORE v3.2 // AI ENGINE ONLINE", type: "system" }]);
  const [isRunning, setIsRunning] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState(null);
  const logsEndRef = useRef(null);

  useEffect(() => { logsEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [terminalLogs]);

  const addLog = (text, type = "info") => {
    setTerminalLogs(prev => [...prev, { text, type, timestamp: new Date().toLocaleTimeString() }]);
  };

  const handleInputChange = (section, field, value) => {
    setConfig(prev => ({ ...prev, [section]: { ...prev[section], [field]: value } }));
  };

  // --- NEW AI FUNCTION ---
  const activateAI = async () => {
    addLog("[AI] ANALYZING PROXY GEO-LOCATION & AGE...", "warning");
    try {
      const response = await fetch(`${API_URL}/api/ai_suggest`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            country: config.identity.country, 
            age: config.chronos.genesisOffsetDays 
        })
      });
      const data = await response.json();
      
      setAiSuggestion(data);
      addLog(`[AI] IDENTIFIED PERSONA: ${data.archetype}`, "success");
      addLog(`[AI] SUGGESTION: Visit ${data.suggested_visit_count} sites over ${data.average_dwell_time}.`);
      addLog(`[AI] REASONING: ${data.reasoning}`);

    } catch (e) {
      addLog(`[AI] ERROR: Could not reach Behavioral Engine.`, "error");
    }
  };

  const runGenesis = async () => {
    if (isRunning) return;
    setIsRunning(true);
    setTerminalLogs([{ text: "EXECUTING GENESIS PROTOCOL...", type: "system" }]);
    
    // Construct Payload for Backend (HermitCrabEngine expects 'fullz' and 'proxy')
    const payload = {
        fullz: {
          name: `${config.identity.firstName} ${config.identity.lastName}`,
          address: config.identity.address,
          city: config.identity.city,
          zip: config.identity.zip,
          cc: config.financial.ccNumber,
          exp: config.financial.expiry
        },
        proxy: `${config.network.host}:${config.network.port}`,
        genesis_offset_days: config.chronos.genesisOffsetDays
    };

    try {
        const res = await fetch(`${API_URL}/api/genesis`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if(res.ok) {
            addLog(`[SUCCESS] ARTIFACT GENERATED: ${data.artifact_url}`, "success");
            setDownloadUrl(`${API_URL}${data.artifact_url}`);
        } else {
            addLog(`[ERROR] ${data.error}`, "error");
        }
    } catch(e) {
        addLog(`[FATAL] ${e.message}`, "error");
    } finally {
        setIsRunning(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-green-500 font-mono p-4 flex flex-col">
      <header className="border-b border-green-800 pb-4 mb-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Brain className="h-6 w-6 text-purple-400 animate-pulse" />
          <div>
            <h1 className="text-xl font-bold tracking-widest text-green-400">PROMETHEUS v3.2 <span className="text-purple-400 text-xs">// AI INTEGRATED</span></h1>
            <p className="text-xs text-green-700">BEHAVIORAL INFERENCE ENGINE ACTIVE</p>
          </div>
        </div>
        <button onClick={activateAI} className="flex items-center gap-2 bg-purple-900/30 border border-purple-500/50 text-purple-300 px-3 py-1 rounded hover:bg-purple-900/50 transition-all">
            <Sparkles size={14} /> AUTO-ARCHITECT PROFILE
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow">
        <div className="lg:col-span-7 space-y-6 overflow-y-auto pr-2">
            
          {/* AI SUGGESTION CARD */}
          {aiSuggestion && (
            <div className="border border-purple-500/50 bg-purple-900/10 rounded p-4 mb-4">
                <div className="flex items-center gap-2 text-purple-400 mb-2 font-bold text-sm">
                    <Brain size={16} /> AI STRATEGY SUGGESTION
                </div>
                <div className="grid grid-cols-2 gap-4 text-xs text-purple-200/80">
                    <div>
                        <span className="block text-purple-500 font-bold">ARCHETYPE</span>
                        {aiSuggestion.archetype}
                    </div>
                    <div>
                        <span className="block text-purple-500 font-bold">TRUST SCORE</span>
                        {aiSuggestion.calculated_trust_score}
                    </div>
                    <div>
                        <span className="block text-purple-500 font-bold">REQ. HISTORY</span>
                        {aiSuggestion.suggested_visit_count} Nodes
                    </div>
                    <div>
                        <span className="block text-purple-500 font-bold">TOP SITES</span>
                        {aiSuggestion.top_sites.join(", ")}
                    </div>
                </div>
                <div className="mt-2 text-[10px] text-purple-400/50 italic border-t border-purple-500/20 pt-2">
                    "{aiSuggestion.reasoning}"
                </div>
            </div>
          )}

          {/* ... (Existing Inputs: Identity, Network, Chronos) ... */}
           <div className="border border-green-800/50 bg-black/40 rounded p-4">
             <div className="flex items-center gap-2 mb-4 text-green-400 border-b border-green-900/60 pb-2">
              <User size={16} /><h2 className="text-sm font-bold">IDENTITY</h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <InputGroup label="FIRST NAME" value={config.identity.firstName} onChange={v => handleInputChange('identity', 'firstName', v)} />
                <InputGroup label="LAST NAME" value={config.identity.lastName} onChange={v => handleInputChange('identity', 'lastName', v)} />
                <InputGroup label="ADDRESS" value={config.identity.address} onChange={v => handleInputChange('identity', 'address', v)} fullWidth />
            </div>
          </div>
          
           <div className="border border-green-800/50 bg-black/40 rounded p-4">
             <div className="flex items-center gap-2 mb-4 text-green-400 border-b border-green-900/60 pb-2">
              <Clock size={16} /><h2 className="text-sm font-bold">CHRONOS AGE</h2>
            </div>
            <input type="range" min="0" max="180" value={config.chronos.genesisOffsetDays} onChange={(e) => handleInputChange('chronos', 'genesisOffsetDays', parseInt(e.target.value))} className="w-full h-2 bg-green-900/50 rounded-lg appearance-none cursor-pointer accent-green-500" />
            <div className="text-center mt-2 font-bold">AGE: {config.chronos.genesisOffsetDays} DAYS</div>
          </div>

        </div>

        <div className="lg:col-span-5 flex flex-col gap-6">
          <div className="flex-grow bg-black border border-green-800 rounded p-4 font-mono text-xs overflow-hidden flex flex-col min-h-[300px]">
             <div className="flex-grow overflow-y-auto space-y-1">
              {terminalLogs.map((log, i) => (
                <div key={i} className={`flex gap-2 ${log.type === 'error' ? 'text-red-500' : log.type === 'success' ? 'text-green-300 font-bold' : log.type === 'warning' ? 'text-purple-400' : 'text-green-500/80'}`}>
                  <span className="opacity-50">[{log.timestamp}]</span><span>{log.text}</span>
                </div>
              ))}
              <div ref={logsEndRef} />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
             {downloadUrl ? (
                 <a href={downloadUrl} className="flex items-center justify-center gap-2 border border-green-400 bg-green-900/20 text-green-300 py-3 rounded font-bold hover:bg-green-900/40 col-span-2 animate-pulse">
                    <Download size={16} /> DOWNLOAD ARTIFACT
                 </a>
            ) : (
                <button onClick={runGenesis} disabled={isRunning} className={`flex items-center justify-center gap-2 py-3 rounded font-bold text-black col-span-2 ${isRunning ? 'bg-orange-500 opacity-80' : 'bg-green-500 hover:bg-green-400'}`}>
                    {isRunning ? <Activity className="animate-spin" /> : <Play />} {isRunning ? 'EXECUTING...' : 'INITIATE GENESIS'}
                </button>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}

const InputGroup = ({ label, value, onChange, fullWidth }) => (
  <div className={fullWidth ? 'col-span-2' : ''}>
    <label className="block text-[10px] text-green-700 mb-1 font-bold">{label}</label>
    <input type="text" value={value} onChange={e => onChange(e.target.value)} className="w-full bg-black/60 border border-green-900/60 rounded p-2 text-sm text-green-100 focus:border-green-500 focus:outline-none" />
  </div>
);
